<script src="assets/js/scripts.js"></script>
</body>
</html>